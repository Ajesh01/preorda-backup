import React, { Component } from 'react';
import Navbar from '../Navbar/Navbar';
import './Login.css'



class Login extends Component{
    render(){
        return (
            <div>
                <Navbar/>          
              <div style={{ minHeight: '85vh'}}>

            <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '85vh'}}>
               
               <div class="card p-3 text-center py-4 px-3 mt-3 login-card">
                   <h4 class="fw-bold">Login</h4>
                   <div>
                       <span>Don’t have an account?</span>
                       <a href="#" class="text-decoration-none"> Signup</a>
                   </div>
                   <hr/>
                   <div class="d-inline-flex p-3 pb-1">
                   <label for="email" class="form-label fw-bold" >email address</label>
                   </div>
                   
                   <div class=" px-3">
                   
                       <input class="form-control" id="email" placeholder="name@example.com"/>
                   </div>
                   
                   
                   <div class="d-inline-flex p-3 pb-1">
                   <label for="inputPassword" class="form-label pl-2 pr-0 fw-bold">password</label>
                    
                    </div>
                   <div class=" px-3">
                       <input type="password" id="inputPassword" class="form-control" placeholder=""/>
                   </div>
                   
                   <div class="mt-3 d-grid px-3">
                       <button class="btn btn-primary btn-block btn-signup text-uppercase">
                           <span>Signin</span>
                           
                       </button>
                   </div>
                   
                  
               </div>
                
         
         </div></div>
         </div>

         )
        
    }
}

export default Login