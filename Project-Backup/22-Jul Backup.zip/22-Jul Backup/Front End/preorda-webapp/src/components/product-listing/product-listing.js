import React, { Component } from 'react';
import Navbar from '../Navbar/Navbar';
import './product-listing.css'


class productListing extends Component {
    render() {
        return (
            <div>
                <Navbar />
                <div class="container-fluid">
                    <div class="row">
                        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                            <div class="position-sticky pt-3">
                                <ul class="nav flex-column">
                                    <li class="nav-item left-nav-text">
                                        <a class="nav-link active " aria-current="page" href="#">
                                            <span data-feather="home"></span>
                                            Electronics
                                        </a>
                                    </li>
                                    <li class="nav-item left-nav-text">
                                        <a class="nav-link" href="#">
                                            <span data-feather="file"></span>
                                            Groceries
                                        </a>
                                    </li>
                                    <li class="nav-item left-nav-text">
                                        <a class="nav-link" href="#">
                                            <span data-feather="shopping-cart"></span>
                                            household supplies
                                        </a>
                                    </li>
                                    <li class="nav-item left-nav-text">
                                        <a class="nav-link" href="#">
                                            <span data-feather="users"></span>
                                            Clothing
                                        </a>
                                    </li>


                                </ul>


                            </div>
                        </nav>

                        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom top-title">
                                <h1 class="h2">Products</h1>
                                <div class="btn-toolbar mb-2 mb-md-0">
                                    <div class="btn-group me-2">
                                        {/* <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button> */}
                                    </div>
                                    <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                                        <span data-feather="calendar"></span>
                                        Sort by
                                    </button>
                                </div>
                            </div>

                            {/* <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> */}


                            <div class="album py-5 bg-light ">
                                <div class="container">
                                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" data-aos="fade-up">
                                        <div class="col" >
                                            {/* <div class="card shadow-sm prod-card">
            <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>

            <div class="card-body">
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div> */}
                                            <div class="card p-3 prod-card">

                                                <div class="text-center">

                                                    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

                                                </div>

                                                <div class="product-details">

                                                <span class="prod-title">Red Radish</span>
                                                    <span class=" d-block">Rs. 7.00</span>
                                                    


                                                    <div class="buttons d-flex  flex-row-reverse">
                                                       <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div>
                                                    </div>

                                                    {/* <div class="weight">

                                                        <small>1 piece 2.5kg</small>

                                                    </div> */}

                                                </div>

                                            </div>
                                        </div>
                                        <div class="col">
                                        <div class="card p-3 prod-card">

<div class="text-center">

    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

</div>

<div class="product-details">

<span class="prod-title">Red Radish</span>
    <span class=" d-block">Rs. 7.00</span>
    


    <div class="buttons d-flex  flex-row-reverse">
       <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div>
    </div>

     

</div>

</div>
                                        </div>
                                        <div class="col">
                                        <div class="card p-3 prod-card">

<div class="text-center">

    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

</div>

<div class="product-details">


   <span class="prod-title">Red Radish</span>
    <span class=" d-block">Rs. 7.00</span>


    <div class="buttons d-flex  flex-row-reverse">
       <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div>
    </div>

    {/*   */}

</div>

</div>
                                        </div>

                                        <div class="col">
                                        <div class="card p-3 prod-card">

<div class="text-center">

    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

</div>

<div class="product-details">


   <span class="prod-title">Red Radish</span>
    <span class="font-weight-bold d-block">Rs. 7.00</span>


    <div class="buttons d-flex  flex-row-reverse">
       <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div>
    </div>

     

</div>

</div>
                                        </div>
                                        <div class="col">
                                        <div class="card p-3 prod-card">

<div class="text-center">

    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

</div>

<div class="product-details">


   <span class="prod-title">Red Radish</span>
    <span class=" d-block">Rs. 7.00</span>


    <div class="buttons d-flex flex-row-reverse">
        <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div> 
        
    </div>

     

</div>

</div>
                                        </div>
                                        <div class="col">
                                        <div class="card p-3 prod-card">

<div class="text-center">

    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

</div>

<div class="product-details">


   <span class="prod-title">Red Radish</span>
    <span class=" d-block">Rs. 7.00</span>


    <div class="buttons d-flex flex-row-reverse">
    <div class="cart">To cart<i class="fa fa-shopping-cart"></i></div>
        
    </div>

     

</div>

</div>
                                        </div>



                                    </div>
                                </div>
                            </div>

                        </main>
                    </div>
                </div>
            </div>
        )
    }
}

export default productListing