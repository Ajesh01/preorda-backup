import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import SellerNavbar from '../seller-nav/Seller-Header';
import './seller-home.css'
const SellerHome = () => {
  const [users, setUser] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:3003/users");
    setUser(result.data.reverse());
  };

  const deleteUser = async id => {
    await axios.delete(`http://localhost:3003/users/${id}`);
    loadUsers();
  };

  return (

    <div>
    <SellerNavbar/>
    <div className="container">
      <div className="py-4">
        <h1>Inventory Page</h1>
        <table class="table table-hover border shadow ">
          <thead class="thead-dark">
            <tr>
              <th scope="col" class="text-primary" >#</th>
              <th scope="col" class="text-primary" >Product Name</th>
              <th scope="col" class="text-primary" >Product Price</th>
              <th scope="col" class="text-primary" >Quantity</th>
              <th  class="text-primary" >Action</th>
            </tr>
          </thead>
              <tbody>
      <tr>
        <th scope="row">1</th>
        <td>Pen</td>
        <td>5</td>
        <td>50</td>
        <td> <Link className="btn  btn-primary btn-block" to="/products/edit">Edit</Link></td>
      </tr>
      <tr>
        <th scope="row">2</th>
        <td>Pencil</td>
        <td>6</td>
        <td>60</td>
        <td> <Link className="btn btn-primary btn-block" to="/products/edit">Edit</Link></td>
      </tr>
      <tr>
        <th scope="row">3</th>
        <td>Eraser</td>
        <td>5</td>
        <td>50</td>
        <td> <Link className="btn  btn-primary btn-block" to="/products/edit">Edit</Link></td>
      </tr>
    </tbody>
        </table>
      </div>
    </div>
    </div>
  );
};

export default SellerHome;
