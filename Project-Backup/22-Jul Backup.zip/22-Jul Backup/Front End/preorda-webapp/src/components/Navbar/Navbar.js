import React, { Component } from 'react';
import './Navbar.css';


class Navbar extends Component{
    render(){
        return (
            <nav class="navbar navbar-expand-lg navbar-custom sticky-top" >
  <div class="container-fluid">
    <a class="navbar-brand nav-text" href="#">LOGO</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll">
        <li class="nav-item ">
          <a class="nav-link active nav-text" aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-text" href="/products">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-text" href="#">Popular</a>
        </li>
      
      </ul>

      <div class="d-flex" >
      <a  href="/cart"><button class="btn btn-warning enlarge-quick" type="submit">Cart</button></a>
      </div>

    </div>
  </div>
</nav>
        )
    }
}

export default Navbar
