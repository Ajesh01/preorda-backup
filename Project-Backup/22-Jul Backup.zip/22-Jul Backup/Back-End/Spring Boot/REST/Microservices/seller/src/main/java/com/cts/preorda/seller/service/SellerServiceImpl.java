package com.cts.preorda.seller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.seller.model.Seller;
import com.cts.preorda.seller.repository.SellerRepository;

@Service
public class SellerServiceImpl implements SellerService{

	@Autowired
	SellerRepository sellerRepo;

	@Override
	public Seller storeSellerDetails(Seller seller) {		
		return sellerRepo.save(seller);

	}
	
}
