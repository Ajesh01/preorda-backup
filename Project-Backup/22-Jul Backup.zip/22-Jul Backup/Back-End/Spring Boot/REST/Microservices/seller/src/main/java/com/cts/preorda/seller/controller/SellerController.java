package com.cts.preorda.seller.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.seller.model.Seller;
import com.cts.preorda.seller.service.SellerService;


@RestController
@RequestMapping("/Seller")
@CrossOrigin
public class SellerController {
	
	@Autowired
	SellerService sellerService;

	@PostMapping("/Register")
	public String processRegister(@RequestBody Seller seller) {

		sellerService.storeSellerDetails(seller);
		
		return "register success";
	}

}
