package com.cts.preorda.seller.service;

import com.cts.preorda.seller.model.Seller;

public interface SellerService {

	public Seller storeSellerDetails(Seller seller);
	
}
