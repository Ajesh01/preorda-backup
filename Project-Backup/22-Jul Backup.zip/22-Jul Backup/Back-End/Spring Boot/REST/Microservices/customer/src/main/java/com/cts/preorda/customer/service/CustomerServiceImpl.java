package com.cts.preorda.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepo;

	@Override
	public Customer storeUserDetails(Customer customer) {		
		return customerRepo.save(customer);

	}

}
