package com.cts.preorda.customer.model;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int customer_Id;
	@Column(nullable = false, length = 25)
	private String first_name;
	@Column(nullable = false, length = 25)
	private String last_name;
	@Column(nullable = false, length = 100)
	private String email;
	@Column(nullable = false, length = 60)
	private String password;
//	@Column(length = 6)
//	private String gender;
//	@Column(length = 8)
//	@JsonFormat(pattern="dd-MM-yyyy")
//	private Date dob;
	@Column(nullable = false, length = 10)
	private String phone_number;
//	@Column(nullable = false, length = 10)
//	private int user_id;

}
