package com.cts.preorda.customer.service;

import java.util.List;

import com.cts.preorda.customer.model.Orders;

public interface OrderService {
	public Orders storeOrderDetails(Orders order);
	public List<Orders> getMyOrders(int user_Id);
	public int get_ord_id(int user_id);

}
