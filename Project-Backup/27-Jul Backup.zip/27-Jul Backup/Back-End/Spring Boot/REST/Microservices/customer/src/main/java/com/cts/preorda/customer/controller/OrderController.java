package com.cts.preorda.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Addresses;
import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.model.OrderPlacing;
import com.cts.preorda.customer.model.Orders;
import com.cts.preorda.customer.model.Schedules;
import com.cts.preorda.customer.repository.ScheduleRepository;
import com.cts.preorda.customer.service.AddressService;
import com.cts.preorda.customer.service.CartService;
import com.cts.preorda.customer.service.OrderDetailsService;
import com.cts.preorda.customer.service.OrderService;
import com.cts.preorda.customer.service.ScheduleService;

@RestController
@RequestMapping("/order")
@CrossOrigin(origins = "http://localhost:3000/")

public class OrderController {
	
	@Autowired
	OrderService orderservice;
	
	@Autowired
	ScheduleService scheduleService;

  @Autowired
	OrderDetailsService orderdetailsservice;
  
  @Autowired
	ScheduleService scheduleservice;
	
	@Autowired
	CartService cartService;


	//Add to cart
	@PostMapping("/add")
	public int processPlaceOrder(@RequestBody Orders order) {
	    Orders insertorder = orderservice.storeOrderDetails(order);
		System.out.println("insertorder.order_Id = " + insertorder.order_Id);
		int order_Id = insertorder.order_Id;
		return order_Id;
	}
	
	@GetMapping("/myorders/{user_id}")
	public List<Orders> getMyOrders(@PathVariable int user_id){		
		List<Orders> order = orderservice.getMyOrders(user_id);
 		return order;
	}
	@Autowired
	AddressService addressService;
	
	@GetMapping("/myaddress/{user}")
	public List<Addresses> getAddress(@PathVariable int user) {
		
		
		List<Addresses> addressList = addressService.getAddress(user);
		System.out.println(addressList);
		return addressList;
	}
	
	@PostMapping("/saveaddress")
	public String handleSaveaddress(@RequestBody Addresses address) {
			
			 addressService.saveAddress(address);
			 return "Address Saved!";
		}
	

    @PostMapping("/scheduleorder")
    public String postBody(@RequestBody String all_details) {
    	
    	
    	String[] details = all_details.split(",", 2);
//    	System.out.println(Arrays.toString(arrOfStr));
    	int uid = Integer.parseInt(details[0]);
    	int order_id = orderservice.get_ord_id(uid);
    	
    	Schedules s = scheduleService.add_schedule(uid, order_id, details[1]);
    	
    	
        return "added order scheuld";
        
    }

	@PostMapping("/placeorder")
	public String handleorderplacing(@RequestBody OrderPlacing orig_details) {
			
			 Addresses address = new Addresses();
			 
			 address.setHouse_no(orig_details.getHouse_no());
			 address.setStreet(orig_details.getStreet());
			 address.setCity(orig_details.getCity());
			 address.setPincode(orig_details.getPincode());
			 address.setState(orig_details.getState());
			 address.setUser(orig_details.getUser());
			
			 addressService.saveAddress(address);
			 
			 
			 Orders order = new Orders();
			 
			 order.setGrand_total(orig_details.getGrand_total());
			 order.setNo_of_items(orig_details.getNo_of_items());
			 order.setOrdertype(orig_details.getOrdertype());
			 order.setSchedule("MONTHLY");
			 order.setOrderPlacedDate(orig_details.getOrderPlacedDate());
			 order.setStatus("PLACED");
			 order.setUser(orig_details.getUser());
			 	 			 
			Orders insertorder = orderservice.storeOrderDetails(order);
			System.out.println("insertorder.order_Id = " + insertorder.order_Id);
			int order_Id = insertorder.order_Id;
			
			List<OrderDetails> c_products = orig_details.getOrder_products();
			
			for (int i = 0; i < c_products.size(); i++)   
			{  
			//prints the elements of the List  
//			System.out.println(city.get(i));
				
				
//				c_products.order_id = order_Id;
//				c_products.get(i).
				
				OrderDetails order_item = new OrderDetails();
				order_item.setOrderid(order_Id);
				order_item.setProduct_id(c_products.get(i).getProduct_id());
				order_item.setProduct_name(c_products.get(i).getProduct_name());
				order_item.setSubtotal(c_products.get(i).getSubtotal());
				order_item.setUser(c_products.get(i).getUser());
				order_item.setQuantity(c_products.get(i).getQuantity());
				orderdetailsservice.storeMyOrderDetails(order_item);
				
			}
			
			cartService.emptyCart(orig_details.getUser());
			
			System.out.println(orig_details.getSchedule().getClass().getSimpleName());
			
			
			if(orig_details.getOrdertype().equals("SCHEDULE")) {
				scheduleservice.add_schedule(orig_details.getUser(), order_Id, orig_details.getSchedule());
				
			}
			
			
			
			
			 
			 return "order Saved!";
			 
			 
			 
			 
			 
		}


}
