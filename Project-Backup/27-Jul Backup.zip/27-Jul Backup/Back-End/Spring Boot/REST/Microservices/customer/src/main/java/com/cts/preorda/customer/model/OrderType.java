package com.cts.preorda.customer.model;

public enum OrderType {

	NORMAL ("Normal"),
	SCHEDULE ("Schedule");
	
	private final String name;
	
		OrderType(String name){
			this.name = name;
		}
}
