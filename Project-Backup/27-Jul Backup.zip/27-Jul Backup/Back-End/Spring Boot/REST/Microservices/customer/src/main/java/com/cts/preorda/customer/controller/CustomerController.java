package com.cts.preorda.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	

	@PostMapping("/register")
	public String processRegister(@RequestBody Customer customer) {
		


		customerService.storeUserDetails(customer);
		
		
		return "register success";
	}
}
