package com.cts.preorda.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.model.Schedules;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedules, Integer> {
	
	@Query(value = "select grand_total from orders where order_id = :oid", nativeQuery = true)
	double get_order_total(@Param("oid")int order_id);
	
	@Query(value = "select user from orders where order_id = :oid", nativeQuery = true)
	int get_uid_with_oid(@Param("oid")int order_id);
	
	@Query(value = "select * from customer where user_id = :uid", nativeQuery = true)
	Customer get_user_details_with_uid(@Param("uid")int uid);
	
	@Query(value = "select username from users where user_id = :uid", nativeQuery = true)
	String get_email_with_uid(@Param("uid")int uid);
}
