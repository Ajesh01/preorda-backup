package com.cts.preorda.customer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
//@Data
//@Getter
//@Setter

public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int orderdetails_Id; 
	@Column(nullable = false, length = 10)
	private int orderid; 
	@Column(nullable=false,length=10)
	private int user;
	@Column(nullable = false, length = 25)
	private int product_id;
	@Column(length = 25)
	private String product_name;
	@Column(nullable = false, length = 100)
	private int quantity;
	@Column(nullable = false, length = 60)
	private double subtotal;
	
	
//	public OrderDetails( int orderid2, int user2, int product_id2, String product_name2,
//			int quantity2, double subtotal2) {
//		// TODO Auto-generated constructor stub
//	}
//	
//    public OrderDetails(OrderDetails order) {
//        this( order.orderid, order.user,order.product_id,order.product_name,order.quantity,order.subtotal);
//    }
//	
	
	


	public int getOrderdetails_Id() {
		return orderdetails_Id;
	}
	public void setOrderdetails_Id(int orderdetails_Id) {
		this.orderdetails_Id = orderdetails_Id;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}	
	
	

}
