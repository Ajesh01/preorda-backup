package com.cts.preorda.customer.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.preorda.customer.model.Orders;

@Repository

public interface OrderRepository extends JpaRepository<Orders, Integer>{

	public List<Orders> findByUser(int user_id);
	
	@Query(value = "select max(order_id) as order_id from orders where user = :uid", nativeQuery = true)
	int get_order_id(@Param("uid")int user_id);
	
	

}
