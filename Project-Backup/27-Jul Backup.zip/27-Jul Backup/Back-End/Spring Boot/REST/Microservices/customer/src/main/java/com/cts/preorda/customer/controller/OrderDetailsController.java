package com.cts.preorda.customer.controller;



import java.util.List;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.service.OrderDetailsService;

@RestController
@RequestMapping("/orderdetails")
@CrossOrigin(origins = "http://localhost:3000/")

public class OrderDetailsController {

	@Autowired
	OrderDetailsService orderdetailsservice;

	//Add to cart
//	@PostMapping("/add")
//	public String processViewMyOrders(@RequestBody OrderDetails orderdetail) {
//
//		orderdetailsservice.storeMyOrderDetails(orderdetail);
//		
//		return "Order details added";
//	}
	
	
//	@PostMapping("/add")
//	public String processViewMyOrders(@RequestBody List<OrderDetails> orderslist) {
//		
//		
//		orderslist.forEach(
//	            (single_prod) -> { 
//	            	
//	            	
//	            	orderdetailsservice.storeMyOrderDetails(single_prod);
//	            
//	            });
	    
	


//		orderdetailsservice.storeMyOrderDetails(orderdetail);
		
//		return "Order details added";
//	}
	
	
	@GetMapping("/myorders/{orderid}")
	public List<OrderDetails> viewMyOrdersHistory(@PathVariable int orderid){
		
		List<OrderDetails> orderdetail = orderdetailsservice.viewMyOrdersHistory(orderid);
 		return orderdetail;
	}

}
