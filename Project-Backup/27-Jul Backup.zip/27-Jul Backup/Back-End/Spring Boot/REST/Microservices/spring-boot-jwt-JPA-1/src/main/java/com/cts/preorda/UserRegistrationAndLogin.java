package com.cts.preorda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegistrationAndLogin {

	public static void main(String[] args) {
		SpringApplication.run(UserRegistrationAndLogin.class, args);
	}
}