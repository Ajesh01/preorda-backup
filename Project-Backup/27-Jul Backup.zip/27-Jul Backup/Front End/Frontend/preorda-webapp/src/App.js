import React, { Component } from "react";
import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import SellerHome from "./components/seller-home/Home";
import About from "./components/pages/About";
import Contact from "./components/pages/Contact";
import SellerNavbar from "./components/seller-nav/Seller-Header";
import EditProduct from "./components/seller-inventory/Edit-Product-Inventory-Page";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  withRouter
} from "react-router-dom";
import NotFound from "./components/pages/NotFound";
import AddProduct from "./components/seller-inventory/Add-Product-Inventory-Page";



import SellerRegistration from './components/SellerRegistration/SellerRegistration';

import './App.css';
import Footer from './components/Footer/Footer';
import Home from './components/Home/Home';
import Signup from './components/Signup/Signup';


import Login from './components/Login/Login'

import Checkout from "./components/Cart/Checkout";
import ProductListing from "./components/product-listing/product-listing";
import MyOrders from "./components/Cart/MyOrders";
import Cartpage from "./components/Cart/Cartpage";
import { useState } from "react";
// import Protected from "./components/Protected";
import { Collapse } from "bootstrap";
function App(props) {

  //localStorage.setItem("user_Id", 103);

  function loadScript(src) {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = src;
      script.onload = () => {
        resolve(true);
      };
      script.onerror = () => {
        resolve(false);
      };
      document.body.appendChild(script);
    });
  }

  const [userState, setUserState] = useState(localStorage.getItem("loginToken"));

  //const [isAuth, setIsAuth]= useState(true);
  return (
    <Router>
      <div className="App">



        <Routes>
          <Route path="/" element={<Home />} />
          {/*<Route  path="/" element={<Protected Component={Home} /> } />*/}
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/products" element={<ProductListing />} />
          <Route path="/myorders" element={<MyOrders />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/seller/product/add" element={<AddProduct />} />
          <Route path="/seller/edit-products/:id" element={<EditProduct />} />
          <Route path="/seller-signup" element={<SellerRegistration />} />
          <Route path="/seller/home" element={<SellerHome />} />
          <Route path="/seller/add-product" element={<AddProduct />} />
          <Route path="/cart/checkout" element={<Checkout />} />

          <Route path="/cart" element={<Cartpage />} />

          <Route component={NotFound} />
        </Routes>

        <Footer />
      </div>
    </Router>

  );
}

export default App;
