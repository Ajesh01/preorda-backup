import React, { useState } from 'react';
import './SellerRegistration.css'
import Navbar from '../Navbar/Navbar';
import axios from 'axios';

function SellerRegistration() {

    const handleClick = (e) => {
        e.preventDefault()
        var seller_details = {
            seller_name,
            phone_number,
            house_no,
            street,
            city,
            pincode,
            state,
            country
            // address
        }

        const login_creds = { username,
            password}
        // console.log(seller)

        axios.post("http://localhost:5003/auth/register", login_creds)
        .then((response) => {
          if (response.data.user_id > 0 ) {
                    console.log("success    ")
                    seller_details.user_id = response.data.user_id;  
                    axios.post("http://localhost:5002/seller/register", seller_details)
                    .then((response) => {
                        console.log("success");
                    // Navigate("/login");
                    return response.data;
                    });
          }
          return response.data;
        });

    }

    // const [first_name, setFirst_name] = useState('');
    const [seller_name, setSeller_name] = useState('');
    const [username, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [house_no, setHouse_no] = useState('');
    const [phone_number, setPhone_number] = useState('');
    const [street, setStreet] = useState('');
    const [city, setCity] = useState('');
    const [pincode, setPincode] = useState('');
    const [state, setState] = useState('');
    const [country, setCountry] = useState('');
    // const [address, setAddress] = useState([

    //     {
    //         house_no: house_no,
    //         street: street,
    //         city: city,
    //         pincode: pincode,
    //         state: state,
    //         country: country

    //     }
    // ]);



    return (
        <div>
            <Navbar />
            <div style={{ minHeight: '85vh' }}>

                <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '85vh' }} >

                    <div class="card p-3 text-center py-4 seller-card" id="sell_reg">
                        <h4>Register as a seller</h4>
                        <div>
                            <span>Already have an account?</span>
                            <a href="/login" class="text-decoration-none"> Signin</a>
                        </div>

                        <div class="input-group px-3 mt-3">
                            <input type="text" class="form-control" placeholder="Seller/Company name" aria-label="Seller Name" value={seller_name}
                                onChange={(e) => setSeller_name(e.target.value)} />
                            {/* <span></span>
                            <input type="text" class="form-control" placeholder="Last Name" aria-label="Server" value={last_name}
                                onChange={(e) => setLast_name(e.target.value)} /> */}
                        </div>
        
                        <div class="mt-3 px-3">
                            <input class="form-control" placeholder="E-mail" value={username}
                                onChange={(e) => setEmail(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input type="password" id="inputPassword" class="form-control" placeholder="Create Password" value={password}
                                onChange={(e) => setPassword(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input type="number" class="form-control" placeholder="Mobile" value={phone_number}
                                onChange={(e) => setPhone_number(e.target.value)} />
                        </div>

                        <div class="input-group px-3 mt-3">
                            <input type="text" class="form-control" placeholder="House/Flat No." value={house_no}
                                onChange={(e) => setHouse_no(e.target.value)} />
                            <span></span>
                            <input class="form-control" placeholder="Street" value={street}
                                onChange={(e) => setStreet(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input type="dropdown" class="form-control" placeholder="City" value={city}
                                onChange={(e) => setCity(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input class="form-control" placeholder="Pincode" value={pincode}
                                onChange={(e) => setPincode(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input class="form-control" placeholder="State" value={state}
                                onChange={(e) => setState(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input class="form-control" placeholder="Country" value={country}
                                onChange={(e) => setCountry(e.target.value)} />
                        </div>

                        <div class="mt-3 d-grid px-3">
                            <button class="btn login-custom btn-block btn-signup text-uppercase" onClick={handleClick}>
                                <span>Signup</span>

                            </button>
                        </div>

                        <div class="px-3">
                            <div class="mt-2 form-check d-flex flex-row">
                                <input class="form-check-input" type="checkbox" value="" id="services" />
                                <label class="form-check-label ms-2" for="services">
                                    I have read and agree to the terms.
                                </label>
                            </div>
                        </div>
                    </div>


                </div></div>
        </div>
    )
}

export default SellerRegistration