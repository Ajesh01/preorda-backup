import React, { useState, useEffect } from 'react';
import './Cartpage.css';
import Navbar from '../Navbar/Navbar';
var user = localStorage.getItem("user_Id");

function MyOrders() {

    const [myorders, setmyorders] = useState([]);

    useEffect(() => {
        let mounted = true;
        console.log("USER", user);
        fetch("http://localhost:5001/order/myorders/" +
            user, {
            method: "GET",
            headers: { "Content-Type": "application/json" }

        }).then(async response => {
            const data = await response.json();
            //console.log("data", data);
            if (mounted)
                setmyorders(data);
            console.log("setmyorders - length of cart", myorders.length);
        })

        return () => mounted = false;
    }, []);

    const viewMyOrderDetails = (orderid) => {

        fetch("http://localhost:5001/order/myorders/" + orderid, {
            method: "GET",
            headers: { "Content-Type": "application/json" }

        }).then(() => {

            console.log(" Cart updated successfully");

        })

    };

    var CART_HTML = '';
    if (myorders.length > 0) {
        CART_HTML =
            <div className="container px-4 px-lg-5 my-5">
                <div className="row">
                    <div className="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">


                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="p-2 px-3 text-uppercase">Order Date</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">No of items</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Grand Total</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Order Status</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Order Type</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Details</div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        myorders.map((myorder, index) => {

                                            return (
                                                <tr key={index}>
                                                    <td className="align-middle"><strong><span>{myorder.order_placed_date}</span></strong></td>
                                                    <td className="align-middle"><strong><span>   {myorder.no_of_items} </span></strong></td>
                                                    <td className="align-middle"><strong><span className="WebRupee">&#x20B9;</span>{myorder.grand_total}</strong></td>
                                                    <td className="align-middle"><strong><span> {myorder.status} </span></strong></td>
                                                    <td className="align-middle"><strong><span> {myorder.ordertype} </span></strong></td>
                                                    <td className="align-middle"><strong><span>
                                                        <button className="badge checkout-custom rounded-pill" type="submit" onClick={() => viewMyOrderDetails(myorder.orderid, index)}
                                                        >   +  </button>
                                                    </span></strong></td>
                                                </tr>
                                            )
                                        })}

                                </tbody>

                            </table>

                        </div>
                    </div>
                </div>

                <div className="row py-5 p-4 bg-white rounded shadow-xs">

                    <div className="col-lg">
                        <div className="bg-light rounded-pill px-4 py-3 text-uppercase fw-bold text-center">Order summary </div>
                        <div className="p-4">
                            <p className="mb-4 text-center"><em>Shipping and delivery charges will be added.</em></p>
                            <ul className="list-unstyled mb-4">
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Subtotal
                                </strong><strong><span className="WebRupee">&#x20B9;</span>totalCartPrice</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Shipping cost
                                </strong><strong><span className="WebRupee">&#x20B9;</span>150</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Tax
                                </strong><strong><span className="WebRupee">&#x20B9;</span>70</strong></li>
                                <li className="d-flex justify-content-between py-3 border-bottom"><strong className="text-muted">Grand Total</strong>
                                    <h5 className="fw-bold"><span className="WebRupee">&#x20B9;</span>total</h5>
                                </li>
                            </ul><a href="/cart/checkout" className="btn btn-danger rounded-pill py-2 d-md-block">Procceed to checkout</a>
                        </div>
                    </div>
                </div>

            </div>
    }
    else {
        CART_HTML = <div style={{ minHeight: '85vh' }}>

            <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '55vh' }} >
                <div class="card p-3 text-center py-4 seller-card" id="sell_reg"><h3 className='text-center'>Cart is Empty</h3>
                    <a href="/products" className="btn btn-danger rounded-pill py-2 d-md-block" >Add more products</a>
                </div>
            </div>
        </div>

    }

    return (
        <div>
            <Navbar />
            <section className="py-auto">
                {CART_HTML}
            </section>
        </div>

    )
}
export default MyOrders;