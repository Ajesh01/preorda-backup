import React, { useState } from 'react';
import Navbar from '../Navbar/Navbar';
import './Signup.css'

function Signup() {

    const handleClick = (e) => {
        e.preventDefault()
        const customer = {
            first_name,
            last_name,
            username,
            password,
            // gender,
            // dob,
            phone_number,
            // user_id
        }
        console.log(customer)
        fetch("http://localhost:5003/customer/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(customer)

        }).then(() => {

            alert("New customer added");
        })
    }
    const [first_name, setFirst_name] = useState('');
    const [last_name, setLast_name] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    // const [gender, setGender] = useState('');
    // const [dob, setDob] = useState('');
    const [phone_number, setPhone_number] = useState('');
    // const [user_id, setUser_id] = useState('');


    return (
        <div>
            <Navbar/>
                    <div style={{ minHeight: '85vh' }} data-aos="fade-down">
            <form>
                <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '85vh' }}>

                    <div class="card p-3 text-center py-4 signup-card">
                        <h4>Create account</h4>
                        <div>
                            <span>Already have an account?</span>
                            <a href="#" class="text-decoration-none"> Signin</a>
                        </div>

                        {/* <div class="mt-3 px-3">
                        <input class="form-control" placeholder="Username" value={}
          onChange={(e) => set(e.target.value)}/>
                    </div> */}



                        <div class="input-group px-3 mt-3">
                            <input type="text" class="form-control" placeholder="First Name" aria-label="Username" value={first_name}
                                onChange={(e) => setFirst_name(e.target.value)} />
                            <span></span>
                            <input type="text" class="form-control" placeholder="Last Name" aria-label="Server" value={last_name}
                                onChange={(e) => setLast_name(e.target.value)} />
                        </div>

                        <div class="mt-3 px-3">
                            <input class="form-control" placeholder="E-mail" value={username}
                                onChange={(e) => setUsername(e.target.value)} />
                        </div>
                        <div class="mt-3 px-3">
                            <input type="text" id="inputPhno" class="form-control" placeholder="Phone Number" value={phone_number}
                                onChange={(e) => setPhone_number(e.target.value)} />

                        </div>
                        <div class="mt-3 px-3">
                            <input type="password" id="inputPassword" class="form-control" placeholder="Create Password" value={password}
                                onChange={(e) => setPassword(e.target.value)} />

                        </div>

                        <div class="mt-3 d-grid px-3">
                            <button class="btn btn-primary btn-block btn-signup text-uppercase" onClick={handleClick}>
                                <span>Signup</span>

                            </button>
                        </div>

                        <div class="px-3">
                            <div class="mt-2 form-check d-flex flex-row">
                                <input class="form-check-input" type="checkbox" value="" id="services" />
                                <label class="form-check-label ms-2" for="services">
                                    I have read and agree to the terms.
                                </label>
                            </div>
                        </div>
                    </div>


                </div>
            </form>
        </div>
        </div>
    )

}


export default Signup