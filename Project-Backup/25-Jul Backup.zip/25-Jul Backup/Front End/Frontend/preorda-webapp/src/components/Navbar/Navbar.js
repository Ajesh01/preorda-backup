import React, { useState } from 'react';

import './Navbar.css';
import AuthService from "../services/auth.service";
import { useNavigate } from 'react-router-dom';

function Navbar() {

  let navigate = useNavigate();

  var login_flag = AuthService.get_login_status();


  var log_button="";

  // if (login_flag){
  //   log_button = `<button class="btn btn-warning enlarge-quick" type="submit" onClick={handleClick}>Logout</button>`;

  //    }
  //    else{

  //   log_button = `<a  href="/login"><button class="btn btn-warning enlarge-quick" type="submit" >Login</button></a>`;
      
    //  }

  const handleClick = (e) => {
    e.preventDefault()
    // console.log("login page : "+ username)
    AuthService.logout().then(
        () => {
          navigate("/");
          window.location.reload();
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
        //   setLoading(false);
        //   setMessage(resMessage);
        }
      );
}



        return (
            <nav class="navbar navbar-expand-lg navbar-custom sticky-top" >
  <div class="container-fluid">
    <a class="navbar-brand nav-text" href="#">LOGO</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll">
        <li class="nav-item ">
          <a class="nav-link active nav-text" aria-current="page" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-text" href="/products">Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-text" href="#">Popular</a>
        </li>
      
      </ul>

      <div class="d-flex" >
        
       <a  href="/cart"><button class="btn btn-warning enlarge-quick" type="submit" onClick={handleClick}>Logout</button></a>

       
       {/* <div dangerouslySetInnerHTML={{ __html: log_button }}/> */}

       <a  href="/cart"><button class="btn btn-warning enlarge-quick" type="submit">Cart</button></a>
      </div>

    </div>
  </div>
</nav>
        )
    }


export default Navbar
