import axios from "axios";
import setUserState from "../../App"

const API_URL = "http://localhost:5003/customer/";
// const register = (username, email, password) => {
//   return axios.post(API_URL + "signup", {
//     username,
//     email,
//     password,
//   });
// };
const login = (username, password) => {
    console.log("logging in! " + username );
  return axios
    .post(API_URL + "authenticate", {
      username,
      password,
    })
    .then((response) => {
      if (response.data.token) {
        // localStorage.setItem("user", "aa");
        // setUserState('myState');
        
        localStorage.setItem("token", JSON.stringify(response.data.token));
      }
      return response.data;
    });
};
const logout = () => {
  localStorage.removeItem("token");
//   setUserState(null);

};

const get_login_status = () => {
    var flag = JSON.parse(localStorage.getItem("token"));
    console.log(flag)
    if (flag!= null){
        console.log("not null token")
        return 1;
    }
    return 0;
  };

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("token"));
};
const AuthService = {
//   register,
  login,
  logout,
  getCurrentUser,
  get_login_status
};
export default AuthService;
