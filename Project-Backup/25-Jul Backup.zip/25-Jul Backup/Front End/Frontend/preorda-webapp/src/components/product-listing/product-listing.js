import React, { useState, useEffect } from 'react';
import Navbar from '../Navbar/Navbar';
import './product-listing.css'


function ProductListing() {

    const [products, setdisplayproducts] = useState([]);
    //const [categories] = ["electronics", "Groceries", "Household supplies", "Clothing"];


    useEffect(() => {
        let mounted = true;
        fetch("http://localhost:5001/customer/products", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            if (mounted)
                setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })

        return () => mounted = false;
    }, []);

    function ProductListingByCategory(category) {
        console.log("Selected Category = ", category);
        fetch("http://localhost:5001/customer/products/categories/" +
            category, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);

            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };

    function ProductListing() {
        fetch("http://localhost:5001/customer/products", {
            method: "GET",
            headers: { "Content-Type": "application/json" }
            // body: JSON.stringify(myproducts)

        }).then(async response => {
            const data = await response.json();
            console.log("data", data);
            setdisplayproducts(data);
            console.log("setdisplayproducts", products);

        })
    };

    const addToCart = (id, product_name, price) => {
        const addtocart = {
            "customer_Id": 101, //localstorage.getITem()
            "product_Id": id,
            "product_name": product_name,
            "quantity": 1,
            "price": price
        }

        console.log('Successfully Added to cart!');

        fetch("http://localhost:5001/cart/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(addtocart)

        }).then(() => {
            alert(product_name + "- Successfully Added to cart!");
            console.log(id, product_name, price);
        })


    }


    return (
        <div>
            <Navbar />
            <div className="container-fluid">
                <div className="row">
                    <nav id="sidebarMenu" className="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                        <div className="position-sticky pt-3">
                            <ul className="nav flex-column">
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListing()}>
                                        <span>All</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Electronics")}>
                                        <span>Electronics</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Groceries")}>
                                        <span>Groceries</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Household Supplies")}>
                                        <span>Household Supplies</span>
                                    </a>
                                </li>
                                <li className="nav-item left-nav-text" >
                                    <a className="nav-link" aria-current="page" href="#" onClick={e => ProductListingByCategory("Clothing")}>
                                        <span>Clothing</span>
                                    </a>
                                </li>
                            </ul>


                        </div>
                    </nav>

                    <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                        <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom top-title">
                            <h1 className="h2">Products</h1>
                            <div className="btn-toolbar mb-2 mb-md-0">
                                <div className="btn-group me-2">
                                </div>
                                <button type="button" className="btn btn-sm btn-outline-secondary dropdown-toggle">
                                    <span data-feather="calendar"></span>
                                    Sort by
                                </button>
                            </div>
                        </div>

                        <div className="album py-5 bg-light ">
                            <div className="container">
                                <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" data-aos="fade-up">
                                    {products.map(productList =>
                                        <div className="col" >
                                            <div className="card p-3 prod-card">

                                                <div className="text-center">

                                                    <img src="https://i.imgur.com/0M7pldG.jpg" width="200" />

                                                </div>

                                                <div className="product-details">

                                                    <span className="prod-title">{productList.product_name}-{productList.brand}</span>
                                                    <span className=" d-block">Rs.{productList.price}/-</span>




                                                    <div className="buttons d-flex  flex-row-reverse" >
                                                        <div className="cart" onClick={e => addToCart(productList.id, productList.product_name, productList.price)}>To cart<i className="fa fa-shopping-cart"></i></div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>)}
                                </div>
                            </div>
                        </div>

                    </main>
                </div>
            </div>
        </div>
    )

}

export default ProductListing