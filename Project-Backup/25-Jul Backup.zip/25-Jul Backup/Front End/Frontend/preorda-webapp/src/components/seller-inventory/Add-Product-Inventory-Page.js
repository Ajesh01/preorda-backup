

import React, {useState} from 'react'
import {Link } from 'react-router-dom';

import SellerNavbar from '../seller-nav/Seller-Header';

const AddProduct = () => {
    const handleClick = (e) => {
        e.preventDefault()
        const sellerProduct = {
            product_name,
            description,
            price,
            quantity,
            brand,
            }
        console.log(sellerProduct)
        fetch("http://localhost:5002/seller/products/save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
           
            body: JSON.stringify(sellerProduct)

        }).then(() => {
            alert("New product added");
        })
    }
  const [product_name, setProduct_name] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [quantity, setQuantity] = useState('')  
  const [brand,setBrand] = useState('') 
    

    
    return (
        <div>
        <SellerNavbar/>
           <div className = "container">
           <h2 className = "text-center">Add Products </h2>
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                      
                      
                        <div className = "card-body">
                            <form>
                            <div className = "form-group mb-2">
                                    <label className = "form-label"> Product Name :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Product Name"
                                        name = "product_name"
                                        className = "form-control"
                                        value = {product_name}
                                        onChange = {(e) => setProduct_name(e.target.value)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Description about the product:</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter product description"
                                        name = "description"
                                        className = "form-control"
                                        value = {description}
                                        onChange = {(e) => setDescription(e.target.value)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Price :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter first name"
                                        name = "firstName"
                                        className = "form-control"
                                        value = {price}
                                        onChange = {(e) => setPrice(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Quantity :</label>
                                    <input
                                        type = "number"
                                        placeholder = "Enter product quantity"
                                        name = "quantity"
                                        className = "form-control"
                                        value = {quantity}
                                        onChange = {(e) => setQuantity(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label">Product Brand:</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter product brand"
                                        name = "productbrand"
                                        className = "form-control"
                                        value = {brand}
                                        onChange = {(e) => setBrand(e.target.value)}
                                    >
                                    </input>
                                </div>
                                   
                              

                                <button className = "btn btn-primary" onClick={handleClick} >Submit </button>
                                <Link to="/seller/home" className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default AddProduct