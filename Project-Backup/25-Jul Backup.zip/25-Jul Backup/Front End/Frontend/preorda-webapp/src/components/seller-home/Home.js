
import React, {useState,useEffect} from 'react'
import { Link } from 'react-router-dom'

import SellerNavbar from '../seller-nav/Seller-Header'
import { Navbar } from 'react-bootstrap'
import EditProduct from '../seller-inventory/Edit-Product-Inventory-Page'
import axios from "axios";


function SellerHome()  {





import './seller-home.css'

  const [users, setUser] = useState([]);


    const [sellerproducts, setsellerproducts] = useState([]);

    useEffect(() => {
        let mounted = true;
    fetch("http://localhost:5002/seller/products", {
        method: "GET",
        headers: { "Content-Type": "application/json" }
       // body: JSON.stringify(sellerproducts)

    }).then(async response=>{
        const data = await response.json();
        console.log(data);
        if(mounted)
       setsellerproducts(data);
        
    })
    return () => mounted = false;
},[]);

   
function handleSubmit(id) {
    console.log(id);
    fetch("http://localhost:5002/seller/del-products/"+
    id, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
       // body: JSON.stringify(sellerproducts)

    }).then(() => {
        alert("product deleted");
        fetch("http://localhost:5002/seller/products", {
        method: "GET",
        headers: { "Content-Type": "application/json" }
       // body: JSON.stringify(sellerproducts)

    }).then(async response=>{
        const data = await response.json();
        console.log(data);
        //if(mounted)
       setsellerproducts(data)});
    })
  };

    return (
     
       <div> <SellerNavbar/>
       <div className = "container">
          
            <h2 className = "text-center">Seller Products - Inventory</h2>
            <Link to = "/seller/add-product" className = "btn btn-primary mb-2" > Add Products </Link>
            <table className="table table-bordered table-striped">
                <thead>
                    <th> Product Id </th>
                    <th> Product Name</th>
                    <th> Product Description</th>
                    <th> Quantity </th>
                    <th> Product Brand</th>
                    <th> Price</th>
                    <th> Actions </th>
                </thead>
                <tbody>
                    {
                        sellerproducts.map(
                            sellerproduct =>
                            <tr key = {sellerproduct.id}> 
                                <td> {sellerproduct.id} </td>
                                <td> {sellerproduct.product_name} </td>
                                <td> {sellerproduct.description} </td>
                                <td> {sellerproduct.quantity} </td>
                                <td> {sellerproduct.price}</td>
                                <td> {sellerproduct.brand} </td>
                                <td>
                                    <Link className="btn btn-info btn-primary" to={`/seller/edit-products/${sellerproduct.id}`} >Update</Link>
                                    <button className = "btn btn-danger" onClick={e=>handleSubmit(sellerproduct.id)}
                                    style = {{marginLeft:"10px"}}> Delete</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
        </div>
    )
}

export default SellerHome

export function getProducts(){
   
    fetch("http://localhost:5002/seller/products", {
        method: "GET",
        headers: { "Content-Type": "application/json" }
       // body: JSON.stringify(sellerproducts)

    }).then( response=>{
        
        response.json();
    })
    
}

export function handleClick(id) {
    console.log(id);
    fetch("http://localhost:5002/seller/del-products/"+
    id, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
       // body: JSON.stringify(sellerproducts)


    }).then(() => {
        alert("product deleted");
        fetch("http://localhost:5002/seller/products", {
        method: "GET",
        headers: { "Content-Type": "application/json" }
       // body: JSON.stringify(sellerproducts)


    }).then(data=>this.setsellerproducts(data))
    })
}
