package com.cts.preorda.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.preorda.dao.SellerDao;
import com.cts.preorda.model.DAOSeller;
import com.cts.preorda.model.DAOSeller;
import com.cts.preorda.model.SellerDTO;



@Service
public class JwtSellerDetailsService implements UserDetailsService{

	@Autowired
	private SellerDao sellerDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		DAOSeller user = sellerDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	
	public DAOSeller save(SellerDTO user) {
		DAOSeller newUser = new DAOSeller();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setFirst_name(user.getFirst_name());
		newUser.setLast_name(user.getLast_name());
		newUser.setPhone_number(user.getPhone_number());
		int lastUserId = userDao.addingUserId();
		newUser.setUser_id(lastUserId+1);

		return userDao.save(newUser);
	}
	
	
	
	
	
}

