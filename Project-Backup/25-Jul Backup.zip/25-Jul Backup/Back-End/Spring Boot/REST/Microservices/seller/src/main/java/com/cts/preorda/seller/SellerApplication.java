package com.cts.preorda.seller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.repository.ProductsRepository;

@SpringBootApplication
public class SellerApplication{

	public static void main(String[] args) {
		SpringApplication.run(SellerApplication.class, args);
	}

	/*@Autowired
	private ProductsRepository productsRepository;
	 implements CommandLineRunner
	@Override
	public void run(String... args) throws Exception {
		Products product = new Products();
		product.setBrand("Sunsilk");
		product.setDescription("Shampoo for silky hair");
		product.setPrice(500);
		product.setProduct_Name("shampoo");
		product.setQuantity(7);
		
	}*/
	
}
