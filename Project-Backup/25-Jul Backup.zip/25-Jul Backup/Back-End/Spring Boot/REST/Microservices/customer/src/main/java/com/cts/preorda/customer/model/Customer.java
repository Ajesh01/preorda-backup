package com.cts.preorda.customer.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int customer_Id;
	@Column(nullable = false, length = 25)
	private String first_name;
	@Column(nullable = false, length = 25)
	private String last_name;
	@Column(nullable = false, length = 100)
	private String username;
	@Column(nullable = false, length = 60)
	@JsonIgnore
	private String password;
	@Column(nullable = false, length = 10)
	private String phone_number;
	@Column(nullable=false,length=10)
	private int user_id;
}
