package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Cart;
import com.cts.preorda.customer.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{
	@Autowired
	CartRepository cartRepo;

	@Override
	public Cart storeCartDetails(Cart cart) {		
		return cartRepo.save(cart);

	}
	@Override
	public List<Cart> getMyProducts() {
		List<Cart> cart = cartRepo.findAll();
		return cart;
    }
	
	/*public List<Cart> getMyProducts(int customer_Id) {
		List<Cart> cart = cartRepo.findByCustomerId(customer_Id);
		return cart;
    }*/
	
	@Override
	public Cart updateMyCart(Cart cart) {
		return cartRepo.save(cart);
	}
	@Override
	public String removeFromCart(int cart_Id) {
		cartRepo.deleteById(cart_Id);
		return "Removed from cart";
    }

}
