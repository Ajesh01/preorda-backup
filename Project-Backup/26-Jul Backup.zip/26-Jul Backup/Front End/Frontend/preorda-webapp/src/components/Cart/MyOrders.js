import React, { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";
import './Cartpage.css';
import Navbar from '../Navbar/Navbar';
var user = localStorage.getItem("user_Id");
function MyOrders() {

    return (
        <div>
            <Navbar />
            <section className="py-auto">
                <h1>My orders</h1>
            </section>
        </div>

    )
}

export default MyOrders;