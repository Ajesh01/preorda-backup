import React from "react";

const About = () => {
  return (
    <div className="container">
      <div className="py-4">
        <h1>About Page</h1>
        <p className="lead">
          PREORDA is a ecommerce web application where we can schedule the orders for a given frequency and it automatically orders those selected items.
        </p>
      </div>
    </div>
  );
};

export default About;
