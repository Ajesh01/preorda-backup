import React, {useState,useEffect} from 'react'
import {Link } from 'react-router-dom';
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";



import SellerNavbar from '../seller-nav/Seller-Header';

const EditProduct = (e) => {
    const { id } =useParams();

    function handleClick(e){
        e.preventDefault()
        const sellerProduct = {   
              
            product_name,
            description,
            price,
            quantity,
            brand,
            }
        console.log(sellerproducts.id)
        fetch("http://localhost:5002/seller/edit-products/"+sellerproducts.id, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(sellerproducts)

        }).then(() => {

            alert(" product edited successfully");
            
        })
    }
    const [sellerproducts, setsellerproducts] = useState({});
    const [product_id, setProduct_id] = useState(false);
    const { setValue } = useForm({
    });

    function setData(fieldName,e){
        console.log(fieldName)
        console.log(e.target.value)
        e.preventDefault();
        var data = sellerproducts;
        data[fieldName] =e.target.value;
        setsellerproducts({
            'id':data['id'],
            'product_name':data['product_name'], 
            'description':data['description'], 
            'price':data['price'], 
            'quantity':data['quantity'], 
            'brand':data['brand']
        }
            );
        console.log(sellerproducts)

    }

    useEffect(() => {
       
            // get user and set form fields
            fetch("http://localhost:5002/seller/products/"+id,{
                method:"GET",
                headers: { "Content-Type": "application/json" },
             }).then(
                //(
            // product) => {
            //     const fields = ['id','product_name', 'description', 'price', 'quantity', 'brand'];
            //     fields.forEach(field => setValue(field, product[field]));
            //     setsellerproducts(product);
            //     console.log(sellerProduct)
            // }
            async response=>{
                const data = await response.json();
                console.log(data);
                const fields = ['id','product_name', 'description', 'price', 'quantity', 'brand'];
                fields.forEach(field => setValue(field, data[field]));

                
               setsellerproducts(data);
               console.log(sellerproducts)
                
            }
            )
        
    }, []);
  //  const [product_id, setProduct_id] = useState('')
  const [product_name, setProduct_name] = useState('')
  const [description, setDescription] = useState('')
    const [price, setPrice] = useState('')
    const [quantity, setQuantity] = useState('')  
    const [brand,setBrand] = useState('')     
    return (
        <div>
        <SellerNavbar/>
           <div className = "container">
           <h2 className = "text-center">Edit Products </h2>
                <div className = "row">
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                      
                        <div className = "card-body">
                            <form>
                            <div className = "form-group mb-2">
                                    <label className = "form-label"> Product Name :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter Product Name"
                                        name = "product_name"
                                        className = "form-control"
                                        value = {sellerproducts.product_name}
                                        onChange = {(e) => setData('product_name',e)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Description about the product:</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter product description"
                                        name = "description"
                                        className = "form-control"
                                        value = {sellerproducts.description}
                                        onChange = {(e) => setData('description',e)}
                                    >
                                    </input>
                                </div>
                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Price :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter price"
                                        name = "price"
                                        className = "form-control"
                                        value = {sellerproducts.price}
                                        onChange = {(e) => setData('price',e)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Quantity :</label>
                                    <input
                                        type = "number"
                                        placeholder = "Enter product quantity"
                                        name = "quantity"
                                        className = "form-control"
                                        value = {sellerproducts.quantity}
                                        onChange = {(e) => setData('quantity',e)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label">Product Brand:</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter product brand"
                                        name = "brand"
                                        className = "form-control"
                                        value = {sellerproducts.brand}
                                        onChange = {(e) => setData('brand',e)}
                                    >
                                    </input>
                                </div>
                                   
                              

                                <button className = "btn btn-primary" onClick={e=>handleClick(e)} >Submit </button>
                                <Link to="/seller/home" className="btn btn-danger"> Cancel </Link>
                            </form>

                        </div>
                    </div>
                </div>

           </div>

        </div>
    )
}

export default EditProduct