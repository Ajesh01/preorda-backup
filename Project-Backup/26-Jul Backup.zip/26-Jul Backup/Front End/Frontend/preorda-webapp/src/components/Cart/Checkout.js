import React, { useState, useEffect } from 'react';
import './Checkout.css';
import Navbar from '../Navbar/Navbar';
var user = localStorage.getItem("user_Id");
function Checkout() {
  const [selected, setSelected] = useState('Normal');
  const [myproducts, setmyproducts] = useState([]);
  var totalCartPrice = 0;
  useEffect(() => {
    let mounted = true;
    console.log("USER", user);
    fetch("http://localhost:5001/cart/myproducts/" +
      user, {
      method: "GET",
      headers: { "Content-Type": "application/json" }
      // body: JSON.stringify(myproducts)

    }).then(async response => {
      const data = await response.json();
      console.log("data", data);
      if (mounted)
        setmyproducts(data);
      console.log("setmyproducts - length of cart", myproducts.length);
    })

    return () => mounted = false;
  }, []);

  const handleChange = (event) => {
    console.log(event.target.value);
    setSelected(event.target.value);
    //alert(event.target.value);
    /*if (event.target.value === "NORMAL") {
      alert("No scheduling");//dropdown logic
    }*/
  };
  const proceedtoCheckout = () => {
    const customer_address = {
      house_no,
      street,
      city,
      pincode,
      state,
      user
    }
    const placeOrder = {
      "user": user,
      "grand_total": 1500.0,
      "no_of_items": 2,
      "ordertype": "NORMAL",
      "schedule": null,
      "orderPlacedDate": "2013-09-22",
      "status": "PLACED"
    }
    const moveOrderfromCart = {
      "orderdetails_Id": 2,
      "orderid": 23,
      "user": user,
      "product_name": "Dress",
      "quantity": 1,
      "subtotal": 12500.0
    }


    console.log("Saving this address to Address table", customer_address);
    fetch("http://localhost:5001/order/saveaddress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customer_address)

    }).then(() => {
      console.log("Saving Order order type(Normal/Schedule)...", placeOrder);
      fetch("http://localhost:5001/order/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(placeOrder)

      })
    }).then(() => {
      console.log("Saving Order Details...", moveOrderfromCart);
      fetch("http://localhost:5001/orderdetails/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(placeOrder)

      })
    }).then(() => {
      console.log("Emptying cart of that particular user...")
      fetch("http://localhost:5001/cart/myproducts/" +
        user, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },

      })
    }).then(() => {
      console.log("Your order placed successfully!");
      alert("Your order placed successfully!");
    });


  };
  const [house_no, setHouse_no] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [pincode, setPincode] = useState('');
  const [state, setState] = useState('');
  //const [country, setCountry] = useState('');

  return (
    <div>
      <Navbar />
      <div>
        <div className="container card checkout-card">
          <main>
            <div>
              <h4 className="text-center">Checkout</h4>
              <hr className="my-4 line " />
            </div>
            <div className="row g-5">
              <div className="col-md-5 col-lg-4 order-md-last">
                <h4 className="d-flex justify-content-between align-items-center mb-3">
                  <span className="line">Order Summary</span>
                  <span className="badge checkout-custom rounded-pill">{myproducts.length}</span>
                </h4>
                <ul className="list-group mb-3">{myproducts.map((myproduct, index) => {
                  totalCartPrice += myproduct.quantity * myproduct.price;
                  return (

                    <li className="list-group-item d-flex justify-content-between lh-sm">
                      <div>
                        <h6 className="my-0">{myproduct.product_name}</h6>
                        <small className="text-muted">Quantity = {myproduct.quantity} </small>
                      </div>
                      <span className="my-1">Rs.{myproduct.quantity * myproduct.price} /-</span>
                    </li>)
                })}
                </ul>
                <div className="list-group-item d-flex justify-content-between">
                  <h6 className="my-0">Grand Total</h6>
                  <strong>Rs.{totalCartPrice + 150} /-</strong>

                </div>
                <small className="text-muted">Shipping&Tax (+Rs.150)</small>
              </div>

              <div className="col-md-7 col-lg-8">
                <h4 className="mb-3">Billing address</h4>
                <form>
                  <div className="row g-3">
                    <div className="col-sm-6">
                      <input type="text" className="form-control" id="firstName" placeholder="First name" required />
                    </div>

                    <div className="col-sm-6">
                      <input type="text" className="form-control" id="lastName" placeholder="Last name" required />
                    </div>

                    <div className="col-12">
                      <input type="email" className="form-control" id="email" placeholder="E-mail" />
                    </div>

                    <div className="col-sm-6">
                      <input type="text" className="form-control" id="houseNo" placeholder="House/Flat No." value={house_no}
                        onChange={(e) => setHouse_no(e.target.value)} />
                    </div>

                    <div className="col-sm-6">
                      <input type="text" className="form-control" id="street" placeholder="Street" value={street}
                        onChange={(e) => setStreet(e.target.value)} />
                    </div>

                    <div className="col-md-5">
                      <input type="text" className="form-control" id="state" placeholder="State" alue={state}
                        onChange={(e) => setState(e.target.value)} />
                    </div>

                    <div className="col-md-4">
                      <input type="text" className="form-control" id="city" placeholder="City" value={city}
                        onChange={(e) => setCity(e.target.value)} />
                    </div>

                    <div className="col-md-3">
                      <input type="text" className="form-control" id="zip" placeholder="Pincode" value={pincode}
                        onChange={(e) => setPincode(e.target.value)} />
                    </div>
                  </div>


                  {/*<hr className="my-4 line " />

                  <div className="form-check">
                    <input type="checkbox" className="form-check-input" id="same-address" />
                    <label className="form-check-label" for="same-address">Shipping address is the same as my billing address</label>
                  </div>

                  <div className="form-check">
                    <input type="checkbox" className="form-check-input" checked required />
                    <label className="form-check-label" for="save-info">Save this information for next time</label>
                  </div>
                  */}

                  <hr className="my-4 line " />

                  <h4 className="mb-3">Choose your order type</h4>
                  <form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_JwMqDPRzuRbtXP" async> </script> </form>


                  <div className="row g-3 my-3">
                    <div className="col-sm-6 form-check">
                      <input id="normal" name="orderType" type="radio" className="form-check-input" onChange={handleChange}
                        checked={selected === 'NORMAL'} value='NORMAL' required />
                      <label className="form-check-label" for="normal">Normal order</label>
                    </div>
                    <div className="col-sm-6 form-check">
                      <input id="schedule" name="orderType" type="radio" className="form-check-input" onChange={handleChange}
                        checked={selected === 'SCHEDULE'} value='SCHEDULE' required />
                      <label className="form-check-label" for="schedule">Schedule your order</label>
                    </div>
                  </div>

                  <div className="row g-3 my-3">
                    <div className="col-sm-6">
                      <label for="schedule" className="form-label">Select the frequency of your order</label>

                    </div>

                    <div className="col-sm-6">
                      <select className="form-select" id="frquency" required>
                        <option value="">Choose...</option>
                        <option>Daily</option>
                        <option>Weekly</option>
                        <option>Monthly</option>
                        <option>Yearly</option>
                      </select>
                    </div>
                  </div>

                  <hr className="my-4 line " />



                  {/*<h4 className="mb-3">Choose your payment method</h4>


                  <div className="row g-3 my-3">
                    <div className="col-md-4 form-check">
                      {/* <form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_JwMqDPRzuRbtXP" async> </script> </form> */}


                  {/*<input id="credit" name="paymentMethod" type="radio" className="form-check-input" checked required />
                      <label className="form-check-label" for="credit">Credit card</label>
                    </div>
                    <div className="col-md-4 form-check">
                      <input id="debit" name="paymentMethod" type="radio" className="form-check-input" required />
                      <label className="form-check-label" for="debit">Debit card</label>
                    </div>
                    <div className="col-md-4 form-check">
                      <input id="paypal" name="paymentMethod" type="radio" className="form-check-input" required />
                      <label className="form-check-label" for="paypal">PayPal</label>
                    </div>
                  </div>

                  <div className="row gy-3">
                    <div className="col-md-6">
                      <input type="text" className="form-control" id="cc-name" placeholder="Name on card" required />
                      <small className="text-muted">Full name as displayed on card</small>
                    </div>

                    <div className="col-md-6">
                      <input type="text" className="form-control" id="cc-number" placeholder="Credit card number" required />
                    </div>

                    <div className="col-md-6">
                      <input type="text" className="form-control" id="cc-expiration" placeholder="Expiration" required />
                    </div>

                    <div className="col-md-6">
                      <input type="text" className="form-control" id="cc-cvv" placeholder="CVV" required />
                    </div>
                  </div>

                  <hr className="my-4 line " />*/}

                  <button className="w-100 btn btn-danger rounded-pill py-2 d-md-block" onClick={proceedtoCheckout}
                    type="submit">PLACE YOUR ORDER</button>

                  <hr className="my-4 line " />
                </form>
              </div>
            </div>
          </main>

        </div>
      </div>
    </div >
  )
}

export default Checkout