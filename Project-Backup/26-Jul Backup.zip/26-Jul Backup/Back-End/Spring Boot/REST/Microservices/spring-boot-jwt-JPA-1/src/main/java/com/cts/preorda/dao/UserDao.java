package com.cts.preorda.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.preorda.model.DAOUser;

@Repository
public interface UserDao extends CrudRepository<DAOUser, Integer> {

	DAOUser findByUsername(String username);

//	@Query(value = "SELECT IFNULL(highest, 0) from ( select max(high) as highest from (select max(user_id) as high from customer union select max(user_id) as high from seller) as maxtable ) as final;", nativeQuery = true)
//	int addingUserId();
	
	@Query(value = "SELECT  user_id from users where username = :username", nativeQuery = true)
	int get_uid(@Param("username")String username);
	
	@Query(value = "select count(user_id) from seller where user_id = :uid", nativeQuery = true)
	int seller_role_check(@Param("uid")int user_id);
	
	@Query(value = "select count(user_id) from customer where user_id = :uid", nativeQuery = true)
	int customer_role_check(@Param("uid")int user_id);
	

}