package com.cts.preorda.seller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.repository.ProductsRepository;

@Service
public class ProductsService {

	@Autowired
	private ProductsRepository productsRepository;

	public List<Products> getAllProducts() {
		List<Products> products = productsRepository.findAll();
		return products;
	}

	/*
	 * public Products getProducts(int id) { return productsRepository.findById(id);
	 * }
	 */

	public Products saveProducts(Products product) {
		return productsRepository.save(product);
	}

	
	public void deleteProducts(int id) {
		productsRepository.deleteById(id);
	}


	public void update(Products product, int id) {
		// TODO Auto-generated method stub
		 Products products = this.getProducts(id);
		productsRepository.save(product);  
		}

	public Products getProducts(int id) {
		// TODO Auto-generated method g
		Products products= productsRepository.findById(id).get();
		System.out.println(products.toString());
		return products;
	} 
	}


