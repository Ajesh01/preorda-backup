package com.cts.preorda.customer.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter

public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int order_Id; 
	@Column(nullable=false,length=10)
	private int user;
	@Column(nullable = false, length = 60)
	private double grand_total;
	@Column(nullable = false, length = 25)
	private int no_of_items;
	@Column(length = 32, columnDefinition = "varchar(32) default 'NORMAL'")
	@Enumerated(EnumType.STRING)
	private OrderType ordertype;//Scheduled order / Normal
	@Column(length = 32, columnDefinition = "varchar(32)")
	@Enumerated(EnumType.STRING)
	private SchedulePreference schedule; //Daily / Weekly / Monthly/ Yearly
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date orderPlacedDate;
	@Column(length = 32, columnDefinition = "varchar(32) default 'PLACED'")
	@Enumerated(EnumType.STRING)
	private OrderStatus status; //Placed / Dispatched / Delivered

	public OrderType getOrdertype() {
		return ordertype;
	}

	public void setOrdertype(OrderType ordertype) {
		this.ordertype = ordertype;
	}

	public SchedulePreference getSchedule() {
		return schedule;
	}

	public void setSchedule(SchedulePreference schedule) {
		this.schedule = schedule;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	
}
