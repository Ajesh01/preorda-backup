package com.cts.preorda.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Addresses;
import com.cts.preorda.customer.model.Orders;
import com.cts.preorda.customer.service.AddressService;
import com.cts.preorda.customer.service.OrderService;

@RestController
@RequestMapping("/order")
@CrossOrigin(origins = "http://localhost:3000/")

public class OrderController {
	
	@Autowired
	OrderService orderservice;

	//Add to cart
	@PostMapping("/add")
	public String processPlaceOrder(@RequestBody Orders order) {

		orderservice.storeOrderDetails(order);
		
		return "Order placed";
	}
	
	@GetMapping("/myorders/{user_id}")
	public List<Orders> getMyOrders(@PathVariable int user_id){		
		List<Orders> order = orderservice.getMyOrders(user_id);
 		return order;
	}
	@Autowired
	AddressService addressService;
	
	@GetMapping("/myaddress/{user}")
	public List<Addresses> getAddress(@PathVariable int user) {
		
		
		List<Addresses> addressList = addressService.getAddress(user);
		System.out.println(addressList);
		return addressList;
	}
	
	@PostMapping("/saveaddress")
	public String handleSaveaddress(@RequestBody Addresses address) {
			
			 addressService.saveAddress(address);
			 return "Address Saved!";
		}

}
