package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.repository.OrderDetailsRepository;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService{
	
	@Autowired
	OrderDetailsRepository orderdetailsRepo;

	@Override
	public OrderDetails storeMyOrderDetails(OrderDetails orderdetail) {
		return orderdetailsRepo.save(orderdetail);

	}
	public List<OrderDetails> viewMyOrdersHistory(int orderid) {
		List<OrderDetails> orderdetails = orderdetailsRepo.findByOrderid(orderid);
		return orderdetails;
	}
}
