package com.cts.preorda.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Cart;
import com.cts.preorda.customer.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin(origins = "http://localhost:3000/")

public class CartController {
	@Autowired
	CartService cartService;

	//Add to cart
	@PostMapping("/add")
	public String processAddtoCart(@RequestBody Cart cart) {

		cartService.storeCartDetails(cart);
		
		return "Added to cart";
	}
	
	//To display products in the customer cart
	@GetMapping("/allproducts")
	public List<Cart> getAllProducts(){		
		List<Cart> cart = cartService.getAllProducts();
 		return cart;
	}
	@GetMapping("/myproducts/{user_id}")
	public List<Cart> getMyCartDetails(@PathVariable int user_id){
		
		List<Cart> cart = cartService.getMyCartDetails(user_id);
 		return cart;
	}
	
	@PutMapping("/update/{cart_Id}")
	public String processUpdateCart(@RequestBody Cart cart) {
		cartService.updateMyCart(cart);
		return "Your cart is updated";
	}
	@DeleteMapping("/myproducts/{cart_Id}")
	public String removeFromCart(@PathVariable int cart_Id) {
		cartService.removeFromCart(cart_Id);
		return "Removed from cart";
	}
	 @Transactional
	@DeleteMapping("/empty/{user_id}")
	public String emptyCart(@PathVariable int user_id) {
		cartService.emptyCart(user_id);
		return "Cart emptied";
	}
	
	
}
