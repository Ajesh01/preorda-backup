package com.cts.preorda.customer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Addresses {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int address_id;
	@Column(nullable = false, length = 10)
	private String house_no;
	@Column(nullable = false, length = 50)
	private String street;
	@Column(nullable = false, length = 30)
	private String city;
	@Column(nullable = false, length = 30)
	private String state;
	@Column(nullable = false, length = 10)
	private int pincode;
	@Column(nullable = false, length = 10)
	private int user;

}
