package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Addresses;
import com.cts.preorda.customer.repository.AddressRepo;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	AddressRepo addressRepo;

	@Override
	public List<Addresses> getAddress(int user) {
			
			List<Addresses> addressList;
			int addressCount = addressRepo.countByCustomer_id(user);
				
			if(addressCount>0) {
				addressList = addressRepo.getAddressList(user);				
			}
			else {
				addressList=null;
			}
			return addressList;
	}

	@Override
	public Addresses saveAddress(Addresses address) {
		
		return addressRepo.save(address);
	}
	
	

}
