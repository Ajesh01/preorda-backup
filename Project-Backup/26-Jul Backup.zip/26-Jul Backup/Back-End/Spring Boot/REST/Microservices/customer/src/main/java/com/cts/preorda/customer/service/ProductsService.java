package com.cts.preorda.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Products;
import com.cts.preorda.customer.repository.ProductsRepository;

@Service

public class ProductsService {
	@Autowired
	private ProductsRepository productsRepository;

	public List<Products> getAllProducts() {
		List<Products> products = productsRepository.findAll();
		return products;
	}
	
	public List<Products> getAllProductsByCategory(String categories) {
		List<Products> products = productsRepository.findByCategories(categories);
		return products;
	}

}
