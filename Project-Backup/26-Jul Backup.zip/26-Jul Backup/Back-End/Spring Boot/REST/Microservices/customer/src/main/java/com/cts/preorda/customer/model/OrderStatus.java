package com.cts.preorda.customer.model;

public enum OrderStatus {
	PLACED ("Placed"),
	DISPATCHED ("Dispatched"),
	DELIVERED ("Delivered");
	
	private final String statusname;
	
	OrderStatus(String statusname){
		this.statusname = statusname;
	}

}
