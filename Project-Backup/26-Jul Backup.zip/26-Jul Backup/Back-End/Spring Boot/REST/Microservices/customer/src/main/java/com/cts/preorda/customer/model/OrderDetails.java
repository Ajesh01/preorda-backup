package com.cts.preorda.customer.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter

public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, length = 10)
	private int orderdetails_Id; 
	@Column(nullable = false, length = 10)
	private int orderid; 
	@Column(nullable=false,length=10)
	private int user;
	@Column(nullable = false, length = 25)
	private String product_name;
	@Column(nullable = false, length = 100)
	private int quantity;
	@Column(nullable = false, length = 60)
	private double subtotal;	

}
