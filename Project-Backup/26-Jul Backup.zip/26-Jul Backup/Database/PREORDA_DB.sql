use preorda;
show tables;
select * from cart;
select * from products;
select * from orders;
select * from addresses;
select * from order_details;
desc orders; 
desc order_details;
desc addresses;
drop table order_details;
drop table orders;
drop table addresses;
select * from users;








delete from orders where user = 103;
select * from addresses;
insert into addresses(City, house_no, pincode, state, street, user)
values("Madurai", "7B", "625020","TN","Balu",103);
insert into orders(order_id, grand_total, no_of_items, order_placed_date,user)
values(22,1500,2,"2013-09-23",103);
insert into orders(order_id, grand_total, no_of_items, order_placed_date, ordertype, schedule, user)
values(2,9000,5,"2013-09-23","SCHEDULE","YEARLY",103);
drop table order_details; 
DROP TABLE orders;
select * from order_details;
select * from customer;
insert into order_details(product_name, quantity, subtotal, user, orderid)
values("Mobile",2,2500,103,12);
select * from products;
select * from cart;
delete from cart where user = 103;
desc products;
desc cart;
desc seller;
desc cart;


delete from products;
delete from cart;
drop table cart; drop table products; 
delete from cart where cart_id = 101;


insert into products values(1,"Samsung","Electronics","Brief description",14999,"Mobile",50);
insert into products values(2,"Sony","Electronics","Brief description",25000,"Television",50);
insert into products values(3,"Panasonic","Electronics","Brief description",5000,"Iron Box",50);
insert into products values(4,"Philips","Electronics","Brief description",8000,"Heater",50);
insert into products values(5,"Hitachi","Electronics","Brief description",38000,"Air-Conditioner",50);
insert into products values(6,"Orient","Electronics","Brief description",4000,"Table Fan",50);

insert into products values(7,"MilkyMist","Groceries","Brief description",112,"Paneer",50);
insert into products values(8,"Hatsun","Groceries","Brief description",20,"Curd",50);
insert into products values(9,"Nestle","Groceries","Brief description",10,"Maggi",25);
insert into products values(10,"Five Star","Groceries","Brief description",10,"Chocolate",100);
insert into products values(11,"Nagas","Groceries","Brief description",68,"Roasted Rava",60);
insert into products values(12,"GRB","Groceries","Brief description",128,"Ghee",50);

insert into products values(13,"SpotZero","Household supplies","Brief description",1499,"SpinMop",50);
insert into products values(14,"Milton","Household supplies","Brief description",550,"ThermoFlask",50);
insert into products values(15,"Tupperware","Household supplies","Brief description",299,"Waterbottle",50);
insert into products values(16,"Colgate","Household supplies","Brief description",99,"Toothbrush",50);
insert into products values(17,"Vim","Household supplies","Brief description",140,"Dish washing liquid",50);
insert into products values(18,"Dettol","Household supplies","Brief description",99,"Soap",50);

insert into products values(19,"Avasa","Clothing","Brief description",799,"Kurti",50);
insert into products values(20,"Prisma","Clothing","Brief description",550,"Leggings",50);
insert into products values(21,"Reliance","Clothing","Brief description",3599,"Long Chudi",50);
insert into products values(22,"Louis Vuitton","Clothing","Brief description",2999,"Shirt",50);
insert into products values(23,"Gucci","Clothing","Brief description",3125,"Pant",50);
insert into products values(24,"H&M","Clothing","Brief description",3555,"Jeans",50);